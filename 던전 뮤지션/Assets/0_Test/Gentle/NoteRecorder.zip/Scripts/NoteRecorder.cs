﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;

public struct Bundle
{

}

public struct Music
{

}

public class NoteProperty
{
    public float time = -1f;
    public int line = -1;
    public string type = string.Empty;
    public float typevalue = -1;
}

public class NoteRecorder : MonoBehaviour
{

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.Q))
            StartCoroutine(ReadNote());

        if(Input.GetKeyDown(KeyCode.R))
        {
            for (int i = 0; i < GameManager.Instance.Notes.Count; i++)
            {
                //GameManager.Instance.Notes[i].ReverseNote(-1f);
            }
        }

        if (Input.GetKeyDown(KeyCode.S))
            GameManager.Instance.StartRecord();
    }

    private void RecordNote()
    {
    }

    private IEnumerator ReadNote()
    {
        string[] textlines = File.ReadAllLines(@"..\던전 뮤지션\Assets\0_Test\Gentle\NoteRecorder\RecordFile.txt");
        List<NoteProperty> noteproperties = new List<NoteProperty>();
        float storetime = 0f;

        for (int i = 0; i < textlines.Length; i++)
        {
            textlines[i].Trim();

            if (textlines[i][0] != '*')
            {
                string text = string.Empty;
                NoteProperty noteproperty = new NoteProperty();

                for (int j = 0; j < textlines[i].Length; j++)
                {
                    if (textlines[i][j] != ',')
                        text += textlines[i][j];
                    else
                    {
                        if (noteproperty.time == -1f)
                            float.TryParse(text, out noteproperty.time);
                        else if (noteproperty.line == -1)
                            int.TryParse(text, out noteproperty.line);
                        else if (noteproperty.type == string.Empty)
                            noteproperty.type = text;
                        else if (noteproperty.typevalue == -1)
                            float.TryParse(text, out noteproperty.typevalue);

                        text = string.Empty;
                    }
                }

                noteproperties.Add(noteproperty);

                for (int j = 0; j < noteproperties.Count; j++)
                {
                    if (noteproperties[j].time > noteproperty.time)
                    {
                        noteproperties.Remove(noteproperty);
                        noteproperties.Insert(j, noteproperty);
                        break;
                    }
                }
            }
        }

        foreach(NoteProperty note in noteproperties)
        {
            yield return new WaitForSeconds(note.time - storetime);
            storetime = note.time;

            GameManager.Instance.CreateNote(GameManager.Instance.Lines[note.line - 1], note.type.ToNoteType(), note.typevalue);
        }
    }
}
